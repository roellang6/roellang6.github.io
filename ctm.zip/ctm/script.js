

function id(str){
	return document.getElementById(str);
}


function play(){
	id('menu').classList.add('hidden');
}

var kitty = {x: 0, y: 0},
		heart = {x: 4, y: 4},
		score = 0;

document.getElementById('forward').addEventListener("click", () => move('forward'));

document.getElementById('backward').addEventListener("click", () => move('backward'));

document.getElementById('left').addEventListener("click", () => move('left'));

document.getElementById('right').addEventListener("click", () => move('right'));

window.addEventListener("keydown", event => {
  if (event.keyCode == '38') {
    // up arrow
    move('forward');
  }
  else if (event.keyCode == '40') {
    // down arrow
    move('backward');
  }
  else if (event.keyCode == '37') {
    // left arrow
    move('left');
  }
  else if (event.keyCode == '39') {
    // right arrow
    move('right');
  }
});

function move(direction) {

  const endDOM = document.getElementById('restart');
  const controlsDOM = document.getElementById('controls');
  const scoreDOM = document.getElementById('score');

  if(id('player') !== null)
		id('player').id = '';
  if (direction === 'forward')
    kitty.y -= kitty.y > 0 ? 1 : 0;
  if (direction === 'backward')
    kitty.y += kitty.y < 4 ? 1 : 0;
  if (direction === 'left')
    kitty.x -= kitty.x > 0 ? 1 : 0;
  if (direction === 'right')
    kitty.x += kitty.x < 4 ? 1 : 0;
  console.log(kitty.y * 5 + kitty.x);
  id('grid').children[kitty.y * 5 + kitty.x].id = 'player';
  if(kitty.x === heart.x && kitty.y === heart.y){
  		//woot woot!
  		score ++;
  		id('score').innerHTML = score;
  		var x = Math.floor(Math.random() * 5),
  				y = Math.floor(Math.random() * 5);
  		if(x === kitty.x && y === kitty.y){
  			if(Math.floor(Math.random() * 2) === 0){
  				kitty.x -= kitty.x > 0 ? 1 : -1;
  			}else{
  				kitty.y -= kitty.y > 0 ? 1 : -1;
  			}
  		}
  		id('grid').children[y * 5 + x].id = 'heart';
  		heart.x = x;
  		heart.y = y;
  		if(score === 5){
  		    id('grid').innerHTML = '<h1 id="message"></h1>';
  			controlsDOM.style.visibility = 'hidden';
  			scoreDOM.style.visibility = 'hidden';
  			endDOM.style.visibility = 'visible';
  			document.querySelector('.restart-btn').addEventListener('click', function(){
                          window.location.reload();
                          return false;
                        });
  		}
  	}
}






